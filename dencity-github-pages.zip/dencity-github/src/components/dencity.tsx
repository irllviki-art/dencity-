import { useEffect, useRef, useState } from "react";
import {
  Phone,
  MapPin,
  Star,
  Calendar,
  Menu,
  X,
  Sparkles,
  Stethoscope,
  Smile,
  Heart,
  Shield,
  ArrowRight,
  Quote,
  Sun,
  Moon,
} from "lucide-react";
import heroImg from "@/assets/hero-clinic.jpg";
import g1 from "@/assets/gallery-1.jpg";
import g2 from "@/assets/gallery-2.jpg";
import g3 from "@/assets/gallery-3.jpg";
import g4 from "@/assets/gallery-4.jpg";

const PHONE = "+919414094290";
const PHONE_DISPLAY = "+91 94140 94290";
const ADDRESS = "Nagpal Colony, New Dhan Mandi, Sri Ganganagar, Rajasthan 335001";
const MAPS_URL = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent("Dencity Dental Clinic, " + ADDRESS)}`;
const MAPS_EMBED = `https://www.google.com/maps?q=${encodeURIComponent("Dencity Dental Clinic, " + ADDRESS)}&output=embed`;

const nav = [
  { id: "home", label: "Home" },
  { id: "services", label: "Services" },
  { id: "about", label: "About" },
  { id: "pricing", label: "Pricing" },
  { id: "reviews", label: "Reviews" },
  { id: "contact", label: "Contact" },
];

export function Header({ onBook, dark, setDark }: { onBook: () => void; dark: boolean; setDark: (v: boolean) => void }) {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={`fixed top-0 inset-x-0 z-50 transition-all duration-500 ${
        scrolled ? "py-2" : "py-4"
      }`}
    >
      <div className="mx-auto max-w-7xl px-4">
        <div className={`glass rounded-2xl px-4 sm:px-6 py-3 flex items-center justify-between transition-all ${scrolled ? "shadow-[var(--shadow-glass-lg)]" : ""}`}>
          <a href="#home" className="flex items-center gap-2.5 group">
            <div className="relative w-10 h-10 rounded-xl bg-[var(--gradient-primary)] flex items-center justify-center shadow-[var(--shadow-glass)] group-hover:scale-105 transition-transform">
              <Sparkles className="w-5 h-5 text-primary-foreground" />
            </div>
            <div className="leading-tight">
              <div className="font-display font-bold text-lg tracking-tight">Dencity</div>
              <div className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">Dental Clinic</div>
            </div>
          </a>

          <nav className="hidden lg:flex items-center gap-1">
            {nav.map((n) => (
              <a
                key={n.id}
                href={`#${n.id}`}
                className="px-3.5 py-2 text-sm font-medium text-foreground/80 hover:text-foreground rounded-lg hover:bg-white/40 dark:hover:bg-white/10 transition-colors"
              >
                {n.label}
              </a>
            ))}
          </nav>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setDark(!dark)}
              aria-label="Toggle theme"
              className="hidden sm:flex w-10 h-10 items-center justify-center rounded-xl glass-subtle hover:scale-105 transition-transform"
            >
              {dark ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </button>
            <a
              href={`tel:${PHONE}`}
              className="hidden md:flex items-center gap-2 px-3.5 py-2 rounded-xl glass-subtle hover:bg-white/60 dark:hover:bg-white/15 transition-colors text-sm font-medium"
            >
              <Phone className="w-4 h-4 text-primary" />
              <span className="hidden xl:inline">{PHONE_DISPLAY}</span>
              <span className="xl:hidden">Call</span>
            </a>
            <button
              onClick={onBook}
              className="hidden sm:inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-[var(--gradient-primary)] text-primary-foreground text-sm font-semibold shadow-[var(--shadow-glass)] hover:shadow-[var(--shadow-float)] hover:-translate-y-0.5 transition-all"
            >
              <Calendar className="w-4 h-4" />
              Book Appointment
            </button>
            <button
              onClick={() => setOpen(!open)}
              className="lg:hidden w-10 h-10 flex items-center justify-center rounded-xl glass-subtle"
              aria-label="Menu"
            >
              {open ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {open && (
          <div className="lg:hidden mt-2 glass-strong rounded-2xl p-3 animate-fade-in">
            <div className="flex flex-col">
              {nav.map((n) => (
                <a
                  key={n.id}
                  href={`#${n.id}`}
                  onClick={() => setOpen(false)}
                  className="px-4 py-3 rounded-xl text-sm font-medium hover:bg-white/40 dark:hover:bg-white/10"
                >
                  {n.label}
                </a>
              ))}
              <button
                onClick={() => { setOpen(false); onBook(); }}
                className="mt-2 px-4 py-3 rounded-xl bg-[var(--gradient-primary)] text-primary-foreground font-semibold"
              >
                Book Appointment
              </button>
            </div>
          </div>
        )}
      </div>
    </header>
  );
}

export function Hero({ onBook }: { onBook: () => void }) {
  return (
    <section id="home" className="relative pt-32 pb-20 md:pt-40 md:pb-28 overflow-hidden">
      {/* Animated background blobs */}
      <div className="absolute inset-0 -z-10 overflow-hidden">
        <div className="absolute -top-32 -left-20 w-[480px] h-[480px] rounded-full bg-secondary/40 blur-3xl blob" />
        <div className="absolute top-20 -right-20 w-[520px] h-[520px] rounded-full bg-primary/30 blur-3xl blob" style={{ animationDelay: "-6s" }} />
        <div className="absolute bottom-0 left-1/3 w-[400px] h-[400px] rounded-full bg-[var(--mint)]/30 blur-3xl blob" style={{ animationDelay: "-12s" }} />
      </div>

      {/* Floating dental icons */}
      <div className="absolute inset-0 -z-10 pointer-events-none">
        <div className="absolute top-32 left-[8%] float-anim">
          <div className="w-14 h-14 rounded-2xl glass-subtle flex items-center justify-center">
            <Smile className="w-6 h-6 text-primary" />
          </div>
        </div>
        <div className="absolute top-48 right-[10%] float-anim-slow">
          <div className="w-12 h-12 rounded-2xl glass-subtle flex items-center justify-center">
            <Heart className="w-5 h-5 text-[var(--coral)]" />
          </div>
        </div>
        <div className="absolute bottom-24 left-[15%] float-anim" style={{ animationDelay: "-3s" }}>
          <div className="w-12 h-12 rounded-2xl glass-subtle flex items-center justify-center">
            <Shield className="w-5 h-5 text-accent" />
          </div>
        </div>
      </div>

      <div className="mx-auto max-w-7xl px-4">
        <div className="grid lg:grid-cols-12 gap-10 items-center">
          <div className="lg:col-span-7">
            <div className="glass-strong rounded-[2rem] p-8 md:p-12">
              <div className="inline-flex items-center gap-2 glass-subtle px-3.5 py-1.5 rounded-full mb-6 text-xs font-medium">
                <span className="w-2 h-2 rounded-full bg-[var(--mint)] animate-pulse" />
                Open today · 9:00 AM – 9:00 PM
              </div>
              <h1 className="font-display text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold leading-[1.05] tracking-tight">
                Smiles that{" "}
                <span className="gradient-text">redefine</span>{" "}
                confidence.
              </h1>
              <p className="mt-5 text-lg text-foreground/70 max-w-xl">
                Premium dental care in Sri Ganganagar. Painless treatments, transparent pricing, and a team that treats every smile like art.
              </p>
              <p className="mt-2 text-base text-foreground/60 font-medium" lang="hi">
                आपकी मुस्कान, हमारी ज़िम्मेदारी।
              </p>

              <div className="mt-6 flex items-center gap-4">
                <div className="flex items-center gap-1">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 fill-[var(--coral)] text-[var(--coral)]" />
                  ))}
                </div>
                <div className="text-sm font-semibold">5.0</div>
                <div className="text-sm text-muted-foreground">· 288 Google Reviews</div>
              </div>

              <div className="mt-8 flex flex-wrap gap-3">
                <button
                  onClick={onBook}
                  className="inline-flex items-center gap-2 px-6 py-3.5 rounded-2xl bg-[var(--gradient-primary)] text-primary-foreground font-semibold shadow-[var(--shadow-glass)] hover:shadow-[var(--shadow-float)] hover:-translate-y-0.5 transition-all"
                >
                  <Calendar className="w-5 h-5" />
                  Book Appointment
                </button>
                <a
                  href={MAPS_URL}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 px-6 py-3.5 rounded-2xl glass-subtle font-semibold hover:bg-white/60 dark:hover:bg-white/15 transition-colors"
                >
                  <MapPin className="w-5 h-5 text-primary" />
                  Directions
                </a>
                <a
                  href={`tel:${PHONE}`}
                  className="inline-flex items-center gap-2 px-6 py-3.5 rounded-2xl glass-subtle font-semibold hover:bg-white/60 dark:hover:bg-white/15 transition-colors"
                >
                  <Phone className="w-5 h-5 text-primary" />
                  Call Clinic
                </a>
              </div>
            </div>
          </div>

          <div className="lg:col-span-5 relative">
            <div className="relative rounded-[2rem] overflow-hidden glass p-2 hover-lift">
              <img
                src={heroImg}
                alt="Dencity Dental Clinic interior"
                width={1920}
                height={1280}
                className="w-full h-[440px] md:h-[520px] object-cover rounded-[1.6rem]"
              />
              <div className="absolute bottom-6 left-6 right-6 glass-strong rounded-2xl p-4 flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-[var(--gradient-mint)] flex items-center justify-center">
                  <Stethoscope className="w-6 h-6 text-white" />
                </div>
                <div>
                  <div className="font-semibold text-sm">15+ years of trusted care</div>
                  <div className="text-xs text-muted-foreground">10,000+ happy patients in Sri Ganganagar</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

const services = [
  { icon: Stethoscope, title: "Root Canal (RCT)", desc: "Single-sitting painless root canal with rotary endodontics.", price: "₹2,500+", tint: "from-primary/20 to-secondary/20" },
  { icon: Shield, title: "Dental Implants", desc: "Premium Korean & Swiss implants, lifetime warranty available.", price: "₹18,000+", tint: "from-[var(--mint)]/30 to-accent/20" },
  { icon: Smile, title: "Wisdom Tooth", desc: "Surgical extraction with minimal discomfort & quick recovery.", price: "₹3,000+", tint: "from-[var(--coral)]/20 to-primary/20" },
  { icon: Heart, title: "Gum Care", desc: "Scaling, polishing & advanced gum disease treatment.", price: "₹800+", tint: "from-secondary/30 to-[var(--mint)]/20" },
  { icon: Sparkles, title: "Teeth Whitening", desc: "Brighten your smile by 4-8 shades in a single session.", price: "₹6,000+", tint: "from-primary/20 to-[var(--coral)]/20" },
  { icon: Stethoscope, title: "Orthodontics", desc: "Metal, ceramic & clear aligners for perfect alignment.", price: "₹25,000+", tint: "from-accent/30 to-primary/20" },
];

export function Services() {
  return (
    <section id="services" className="py-24 md:py-32 relative">
      <div className="mx-auto max-w-7xl px-4">
        <div className="max-w-2xl mb-16">
          <div className="inline-flex glass-subtle px-3 py-1 rounded-full text-xs font-medium mb-4">Our Services</div>
          <h2 className="font-display text-4xl md:text-5xl font-bold leading-tight">
            World-class treatments, <span className="gradient-text">priced honestly.</span>
          </h2>
          <p className="mt-4 text-foreground/70 text-lg">Every procedure performed with sterilized, single-use instruments and the latest dental technology.</p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((s, i) => {
            const Icon = s.icon;
            return (
              <div key={i} className="reveal glass rounded-3xl p-7 hover-lift group cursor-pointer relative overflow-hidden">
                <div className={`absolute -top-12 -right-12 w-40 h-40 rounded-full bg-gradient-to-br ${s.tint} blur-2xl opacity-70`} />
                <div className="relative">
                  <div className="w-14 h-14 rounded-2xl bg-[var(--gradient-primary)] flex items-center justify-center mb-5 shadow-[var(--shadow-glass)] group-hover:scale-110 group-hover:rotate-3 transition-transform">
                    <Icon className="w-6 h-6 text-primary-foreground" />
                  </div>
                  <h3 className="font-display text-xl font-bold mb-2">{s.title}</h3>
                  <p className="text-sm text-foreground/70 leading-relaxed mb-5">{s.desc}</p>
                  <div className="flex items-center justify-between">
                    <div className="text-sm">
                      <span className="text-xs text-muted-foreground">Starting at</span>
                      <div className="font-bold text-lg gradient-text">{s.price}</div>
                    </div>
                    <ArrowRight className="w-5 h-5 text-primary opacity-0 group-hover:opacity-100 group-hover:translate-x-1 transition-all" />
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

export function About() {
  const stats = [
    { v: "15+", l: "Years Experience" },
    { v: "10k+", l: "Happy Patients" },
    { v: "5.0★", l: "Google Rating" },
    { v: "25+", l: "Treatments" },
  ];
  return (
    <section id="about" className="py-24 md:py-32">
      <div className="mx-auto max-w-7xl px-4">
        <div className="glass-strong rounded-[2.5rem] p-8 md:p-16 relative overflow-hidden">
          <div className="absolute -bottom-32 -left-20 w-96 h-96 rounded-full bg-primary/30 blur-3xl" />
          <div className="absolute -top-20 -right-20 w-96 h-96 rounded-full bg-secondary/30 blur-3xl" />

          <div className="relative grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <div className="inline-flex glass-subtle px-3 py-1 rounded-full text-xs font-medium mb-4">About Dencity</div>
              <h2 className="font-display text-4xl md:text-5xl font-bold leading-tight">
                A clinic built on <span className="gradient-text">trust, comfort & precision.</span>
              </h2>
              <p className="mt-5 text-foreground/70 text-lg leading-relaxed">
                For over a decade, Dencity has been Sri Ganganagar's destination for advanced dental care. Our team blends modern technology with old-fashioned warmth so every visit feels effortless.
              </p>
              <p className="mt-4 text-foreground/70 leading-relaxed">
                From your first consultation to your final smile reveal, we walk with you — explaining every step, every cost, every outcome.
              </p>
            </div>
            <div className="grid grid-cols-2 gap-4">
              {stats.map((s, i) => (
                <div key={i} className="glass rounded-3xl p-6 text-center hover-lift">
                  <div className="font-display text-4xl md:text-5xl font-bold gradient-text">{s.v}</div>
                  <div className="mt-2 text-sm text-foreground/70 font-medium">{s.l}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

export function Pricing() {
  const plans = [
    { name: "Consultation", price: "Free", desc: "First visit, exam & treatment plan", feats: ["Full oral exam", "X-ray review", "Personalised plan", "No obligation"], highlight: false },
    { name: "Smile Makeover", price: "₹15,000", suffix: "/start", desc: "Most popular package", feats: ["Whitening session", "Scaling & polish", "2 free check-ups", "6-month warranty"], highlight: true },
    { name: "Family Care", price: "₹8,500", suffix: "/yr", desc: "Up to 4 family members", feats: ["Annual check-ups", "20% off treatments", "Priority booking", "Kids' dental free"], highlight: false },
  ];
  return (
    <section id="pricing" className="py-24 md:py-32">
      <div className="mx-auto max-w-7xl px-4">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <div className="inline-flex glass-subtle px-3 py-1 rounded-full text-xs font-medium mb-4">Transparent Pricing</div>
          <h2 className="font-display text-4xl md:text-5xl font-bold leading-tight">
            Honest prices. <span className="gradient-text">No surprises.</span>
          </h2>
        </div>
        <div className="grid md:grid-cols-3 gap-6">
          {plans.map((p, i) => (
            <div
              key={i}
              className={`relative rounded-3xl p-8 hover-lift ${
                p.highlight
                  ? "glass-strong border-2 border-primary/40 scale-[1.02]"
                  : "glass"
              }`}
            >
              {p.highlight && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-4 py-1 rounded-full bg-[var(--gradient-primary)] text-primary-foreground text-xs font-bold tracking-wide">
                  MOST POPULAR
                </div>
              )}
              <h3 className="font-display text-xl font-bold">{p.name}</h3>
              <p className="text-sm text-foreground/60 mt-1">{p.desc}</p>
              <div className="mt-6 flex items-baseline gap-1">
                <span className="font-display text-5xl font-bold gradient-text">{p.price}</span>
                {p.suffix && <span className="text-foreground/60 text-sm">{p.suffix}</span>}
              </div>
              <ul className="mt-6 space-y-3">
                {p.feats.map((f, j) => (
                  <li key={j} className="flex items-start gap-3 text-sm">
                    <div className="mt-0.5 w-5 h-5 rounded-full bg-[var(--mint)]/30 flex items-center justify-center flex-shrink-0">
                      <svg className="w-3 h-3" viewBox="0 0 12 12" fill="none">
                        <path d="M2 6l3 3 5-6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                      </svg>
                    </div>
                    {f}
                  </li>
                ))}
              </ul>
              <a
                href={`tel:${PHONE}`}
                className={`mt-8 inline-flex items-center justify-center w-full gap-2 py-3 rounded-2xl font-semibold transition-all ${
                  p.highlight
                    ? "bg-[var(--gradient-primary)] text-primary-foreground shadow-[var(--shadow-glass)] hover:shadow-[var(--shadow-float)]"
                    : "glass-subtle hover:bg-white/60 dark:hover:bg-white/15"
                }`}
              >
                Get Started <ArrowRight className="w-4 h-4" />
              </a>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

const allReviews = [
  { name: "Priya Sharma", initials: "PS", rating: 5, text: "Best dental clinic in Sri Ganganagar! Dr. and the team were so gentle during my root canal. Zero pain, zero stress.", date: "2 weeks ago" },
  { name: "Rajesh Kumar", initials: "RK", rating: 5, text: "Got my implants done here. Premium quality work at very reasonable prices. The clinic feels more like a spa.", date: "1 month ago" },
  { name: "Anjali Mehta", initials: "AM", rating: 5, text: "Took my 6-year-old here and she actually enjoyed the visit! Amazing with kids. Highly recommend.", date: "3 weeks ago" },
  { name: "Vikram Singh", initials: "VS", rating: 5, text: "Honest pricing and honest opinions. Didn't push unnecessary treatments. Will only go here from now on.", date: "2 months ago" },
  { name: "Neha Gupta", initials: "NG", rating: 5, text: "My smile makeover turned out incredible. People keep complimenting me. Worth every rupee!", date: "1 month ago" },
  { name: "Arjun Patel", initials: "AP", rating: 5, text: "Modern equipment, sterile environment and a doctor who actually listens. 10/10 experience.", date: "3 months ago" },
];

export function Reviews() {
  const [visible, setVisible] = useState(3);
  return (
    <section id="reviews" className="py-24 md:py-32">
      <div className="mx-auto max-w-7xl px-4">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6">
          <div className="max-w-xl">
            <div className="inline-flex glass-subtle px-3 py-1 rounded-full text-xs font-medium mb-4">Patient Stories</div>
            <h2 className="font-display text-4xl md:text-5xl font-bold leading-tight">
              Loved by <span className="gradient-text">288 patients</span> on Google.
            </h2>
          </div>
          <div className="glass rounded-2xl px-5 py-4 flex items-center gap-4">
            <div>
              <div className="flex items-center gap-1">
                {[...Array(5)].map((_, i) => <Star key={i} className="w-4 h-4 fill-[var(--coral)] text-[var(--coral)]" />)}
              </div>
              <div className="text-xs text-muted-foreground mt-1">5.0 average</div>
            </div>
            <div className="h-10 w-px bg-border" />
            <div>
              <div className="font-display text-2xl font-bold">288</div>
              <div className="text-xs text-muted-foreground">verified reviews</div>
            </div>
          </div>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {allReviews.slice(0, visible).map((r, i) => (
            <div key={i} className="reveal glass rounded-3xl p-7 hover-lift relative">
              <Quote className="absolute top-6 right-6 w-8 h-8 text-primary/20" />
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 rounded-full bg-[var(--gradient-primary)] flex items-center justify-center text-primary-foreground font-bold">
                  {r.initials}
                </div>
                <div>
                  <div className="font-semibold">{r.name}</div>
                  <div className="text-xs text-muted-foreground">{r.date}</div>
                </div>
              </div>
              <div className="flex items-center gap-0.5 mb-3">
                {[...Array(r.rating)].map((_, j) => <Star key={j} className="w-4 h-4 fill-[var(--coral)] text-[var(--coral)]" />)}
              </div>
              <p className="text-sm text-foreground/80 leading-relaxed">"{r.text}"</p>
            </div>
          ))}
        </div>

        {visible < allReviews.length && (
          <div className="mt-10 text-center">
            <button
              onClick={() => setVisible(allReviews.length)}
              className="inline-flex items-center gap-2 px-6 py-3 rounded-2xl glass-subtle font-semibold hover:bg-white/60 dark:hover:bg-white/15 transition-colors"
            >
              Load more reviews <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>
    </section>
  );
}

const galleryItems = [
  { src: g1, cat: "Happy Patients", w: "md:col-span-2 md:row-span-2" },
  { src: g2, cat: "Reception", w: "" },
  { src: g3, cat: "Equipment", w: "" },
  { src: g4, cat: "Treatments", w: "md:col-span-2" },
  { src: g1, cat: "Smile Care", w: "" },
  { src: g2, cat: "Interior", w: "" },
];

export function Gallery() {
  const [lightbox, setLightbox] = useState<string | null>(null);
  return (
    <section id="gallery" className="py-24 md:py-32">
      <div className="mx-auto max-w-7xl px-4">
        <div className="max-w-2xl mb-12">
          <div className="inline-flex glass-subtle px-3 py-1 rounded-full text-xs font-medium mb-4">Gallery</div>
          <h2 className="font-display text-4xl md:text-5xl font-bold leading-tight">
            Step inside <span className="gradient-text">our space.</span>
          </h2>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 auto-rows-[180px] md:auto-rows-[220px] gap-4">
          {galleryItems.map((g, i) => (
            <button
              key={i}
              onClick={() => setLightbox(g.src)}
              className={`relative overflow-hidden rounded-3xl glass p-1.5 hover-lift group ${g.w}`}
            >
              <img
                src={g.src}
                alt={g.cat}
                loading="lazy"
                width={800}
                height={800}
                className="w-full h-full object-cover rounded-[1.4rem] transition-transform duration-700 group-hover:scale-110"
              />
              <div className="absolute inset-1.5 rounded-[1.4rem] bg-gradient-to-t from-primary/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-5">
                <div className="glass-strong rounded-xl px-3 py-1.5 text-xs font-semibold">
                  {g.cat}
                </div>
              </div>
            </button>
          ))}
        </div>
      </div>

      {lightbox && (
        <div
          onClick={() => setLightbox(null)}
          className="fixed inset-0 z-[100] bg-black/80 md:backdrop-blur-xl flex items-center justify-center p-4 animate-fade-in"
        >
          <button
            className="absolute top-6 right-6 w-12 h-12 rounded-full glass-strong flex items-center justify-center"
            onClick={() => setLightbox(null)}
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
          <img src={lightbox} alt="Gallery enlarged" className="max-w-full max-h-[90vh] rounded-3xl shadow-[var(--shadow-float)]" />
        </div>
      )}
    </section>
  );
}

export function Contact({ onBook }: { onBook: () => void }) {
  return (
    <section id="contact" className="py-24 md:py-32">
      <div className="mx-auto max-w-7xl px-4">
        <div className="grid lg:grid-cols-5 gap-6">
          <div className="lg:col-span-2 glass-strong rounded-[2rem] p-8 md:p-10">
            <div className="inline-flex glass-subtle px-3 py-1 rounded-full text-xs font-medium mb-4">Visit Us</div>
            <h2 className="font-display text-3xl md:text-4xl font-bold leading-tight">Come say hello.</h2>
            <p className="mt-3 text-foreground/70">We're easy to find, easier to talk to.</p>

            <div className="mt-8 space-y-5">
              <a href={MAPS_URL} target="_blank" rel="noopener noreferrer" className="flex items-start gap-4 group">
                <div className="w-11 h-11 rounded-xl bg-[var(--gradient-primary)] flex items-center justify-center flex-shrink-0 shadow-[var(--shadow-glass)]">
                  <MapPin className="w-5 h-5 text-primary-foreground" />
                </div>
                <div>
                  <div className="text-xs uppercase tracking-wider text-muted-foreground font-semibold">Address</div>
                  <div className="text-sm mt-1 group-hover:text-primary transition-colors">{ADDRESS}</div>
                </div>
              </a>
              <a href={`tel:${PHONE}`} className="flex items-start gap-4 group">
                <div className="w-11 h-11 rounded-xl bg-[var(--gradient-mint)] flex items-center justify-center flex-shrink-0 shadow-[var(--shadow-glass)]">
                  <Phone className="w-5 h-5 text-white" />
                </div>
                <div>
                  <div className="text-xs uppercase tracking-wider text-muted-foreground font-semibold">Phone</div>
                  <div className="text-sm mt-1 font-medium group-hover:text-primary transition-colors">{PHONE_DISPLAY}</div>
                </div>
              </a>
              <div className="flex items-start gap-4">
                <div className="w-11 h-11 rounded-xl glass-subtle flex items-center justify-center flex-shrink-0">
                  <Calendar className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <div className="text-xs uppercase tracking-wider text-muted-foreground font-semibold">Hours</div>
                  <div className="text-sm mt-1">Mon – Sat: 9:00 AM – 9:00 PM</div>
                  <div className="text-sm text-muted-foreground">Sunday: By appointment</div>
                </div>
              </div>
            </div>

            <button
              onClick={onBook}
              className="mt-8 w-full inline-flex items-center justify-center gap-2 px-6 py-4 rounded-2xl bg-[var(--gradient-primary)] text-primary-foreground font-semibold shadow-[var(--shadow-glass)] hover:shadow-[var(--shadow-float)] transition-all"
            >
              <Calendar className="w-5 h-5" /> Book Appointment
            </button>
          </div>

          <div className="lg:col-span-3 glass rounded-[2rem] p-2 overflow-hidden min-h-[500px]">
            <iframe
              title="Dencity Dental Clinic location"
              src={MAPS_EMBED}
              loading="lazy"
              className="w-full h-full min-h-[480px] rounded-[1.6rem] border-0"
              referrerPolicy="no-referrer-when-downgrade"
            />
          </div>
        </div>
      </div>
    </section>
  );
}

export function Footer() {
  return (
    <footer className="pt-20 pb-10">
      <div className="mx-auto max-w-7xl px-4">
        <div className="glass-strong rounded-[2rem] p-10 md:p-14">
          <div className="grid md:grid-cols-4 gap-10">
            <div className="md:col-span-2">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-xl bg-[var(--gradient-primary)] flex items-center justify-center">
                  <Sparkles className="w-5 h-5 text-primary-foreground" />
                </div>
                <div>
                  <div className="font-display font-bold text-lg">Dencity</div>
                  <div className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">Dental Clinic</div>
                </div>
              </div>
              <p className="mt-4 text-sm text-foreground/70 max-w-sm">Premium dental care in the heart of Sri Ganganagar. Crafting confident smiles since 2010.</p>
              <form
                onSubmit={(e) => { e.preventDefault(); alert("Thanks for subscribing!"); }}
                className="mt-6 flex gap-2 glass-subtle rounded-2xl p-1.5"
              >
                <input
                  type="email"
                  required
                  placeholder="Your email for clinic updates"
                  className="flex-1 bg-transparent px-4 py-2.5 text-sm outline-none placeholder:text-muted-foreground"
                />
                <button className="px-4 py-2 rounded-xl bg-[var(--gradient-primary)] text-primary-foreground text-sm font-semibold">
                  Subscribe
                </button>
              </form>
            </div>
            <div>
              <div className="text-xs uppercase tracking-wider text-muted-foreground font-semibold mb-4">Quick Links</div>
              <ul className="space-y-2.5 text-sm">
                {nav.map((n) => (
                  <li key={n.id}><a href={`#${n.id}`} className="text-foreground/70 hover:text-primary transition-colors">{n.label}</a></li>
                ))}
              </ul>
            </div>
            <div>
              <div className="text-xs uppercase tracking-wider text-muted-foreground font-semibold mb-4">Connect</div>
              <ul className="space-y-2.5 text-sm">
                <li><a href={MAPS_URL} target="_blank" rel="noopener noreferrer" className="text-foreground/70 hover:text-primary transition-colors">Google Maps</a></li>
                <li><a href={`tel:${PHONE}`} className="text-foreground/70 hover:text-primary transition-colors">{PHONE_DISPLAY}</a></li>
                <li><a href="#" className="text-foreground/70 hover:text-primary transition-colors">Instagram</a></li>
                <li><a href="#" className="text-foreground/70 hover:text-primary transition-colors">Facebook</a></li>
              </ul>
            </div>
          </div>
          <div className="mt-10 pt-6 border-t border-border/50 flex flex-col sm:flex-row justify-between gap-3 text-xs text-muted-foreground">
            <div>© {new Date().getFullYear()} Dencity Dental Clinic. All rights reserved.</div>
            <div>Crafted with care in Sri Ganganagar, Rajasthan.</div>
          </div>
        </div>
      </div>
    </footer>
  );
}

export function BookingModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [form, setForm] = useState({ name: "", phone: "", service: "Consultation", date: "", notes: "" });
  const [sent, setSent] = useState(false);

  useEffect(() => {
    if (open) setSent(false);
  }, [open]);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 animate-fade-in">
      <div className="absolute inset-0 bg-primary/30 md:backdrop-blur-2xl" onClick={onClose} />
      <div className="relative glass-strong rounded-[2rem] p-8 md:p-10 w-full max-w-lg animate-scale-in">
        <button onClick={onClose} className="absolute top-5 right-5 w-10 h-10 rounded-full glass-subtle flex items-center justify-center" aria-label="Close">
          <X className="w-4 h-4" />
        </button>

        {sent ? (
          <div className="text-center py-8">
            <div className="w-16 h-16 mx-auto rounded-full bg-[var(--gradient-mint)] flex items-center justify-center mb-4">
              <svg className="w-8 h-8 text-white" viewBox="0 0 24 24" fill="none">
                <path d="M5 12l5 5L20 7" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </div>
            <h3 className="font-display text-2xl font-bold">Request received!</h3>
            <p className="mt-2 text-foreground/70">We'll call you back within 30 minutes to confirm.</p>
            <button onClick={onClose} className="mt-6 px-6 py-3 rounded-2xl bg-[var(--gradient-primary)] text-primary-foreground font-semibold">
              Close
            </button>
          </div>
        ) : (
          <>
            <h3 className="font-display text-2xl md:text-3xl font-bold">Book your visit</h3>
            <p className="mt-1 text-sm text-foreground/70">We'll confirm by phone within 30 minutes.</p>

            <form
              onSubmit={(e) => { e.preventDefault(); setSent(true); }}
              className="mt-6 space-y-4"
            >
              <div>
                <label className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Full Name</label>
                <input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="mt-1.5 w-full glass-subtle rounded-xl px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-primary/40" placeholder="Your name" />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Phone</label>
                  <input required type="tel" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} className="mt-1.5 w-full glass-subtle rounded-xl px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-primary/40" placeholder="+91" />
                </div>
                <div>
                  <label className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Date</label>
                  <input required type="date" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} className="mt-1.5 w-full glass-subtle rounded-xl px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-primary/40" />
                </div>
              </div>
              <div>
                <label className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Service</label>
                <select value={form.service} onChange={(e) => setForm({ ...form, service: e.target.value })} className="mt-1.5 w-full glass-subtle rounded-xl px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-primary/40">
                  {["Consultation", "Root Canal", "Implants", "Wisdom Tooth", "Gum Care", "Whitening", "Orthodontics"].map((s) => (
                    <option key={s}>{s}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Notes (optional)</label>
                <textarea rows={3} value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} className="mt-1.5 w-full glass-subtle rounded-xl px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-primary/40 resize-none" placeholder="Anything we should know?" />
              </div>
              <button type="submit" className="w-full mt-2 px-6 py-3.5 rounded-2xl bg-[var(--gradient-primary)] text-primary-foreground font-semibold shadow-[var(--shadow-glass)] hover:shadow-[var(--shadow-float)] transition-all">
                Confirm Booking
              </button>
            </form>
          </>
        )}
      </div>
    </div>
  );
}

export function FloatingCTA({ onBook }: { onBook: () => void }) {
  return (
    <button
      onClick={onBook}
      className="fixed bottom-6 right-6 z-40 inline-flex items-center gap-2 px-5 py-3.5 rounded-2xl bg-[var(--gradient-primary)] text-primary-foreground font-semibold shadow-[var(--shadow-float)] hover:scale-105 transition-transform float-anim-slow"
      aria-label="Book appointment"
    >
      <Calendar className="w-5 h-5" />
      <span className="hidden sm:inline">Book Now</span>
    </button>
  );
}

export function useReveal() {
  useEffect(() => {
    const els = document.querySelectorAll(".reveal");
    const io = new IntersectionObserver((entries) => {
      entries.forEach((e) => e.isIntersecting && e.target.classList.add("in"));
    }, { threshold: 0.12 });
    els.forEach((el) => io.observe(el));
    return () => io.disconnect();
  }, []);
}
