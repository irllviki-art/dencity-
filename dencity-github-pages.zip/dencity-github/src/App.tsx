import { useState, useEffect } from "react";
import {
  Header,
  Hero,
  Services,
  About,
  Pricing,
  Reviews,
  Gallery,
  Contact,
  Footer,
  BookingModal,
  FloatingCTA,
  useReveal,
} from "@/components/dencity";

export default function App() {
  const [bookOpen, setBookOpen] = useState(false);
  const [dark, setDark] = useState(false);
  useReveal();

  useEffect(() => {
    document.documentElement.classList.toggle("dark", dark);
  }, [dark]);

  const openBook = () => setBookOpen(true);

  return (
    <div className="relative">
      <Header onBook={openBook} dark={dark} setDark={setDark} />
      <main>
        <Hero onBook={openBook} />
        <Services />
        <About />
        <Pricing />
        <Reviews />
        <Gallery />
        <Contact onBook={openBook} />
      </main>
      <Footer />
      <FloatingCTA onBook={openBook} />
      <BookingModal open={bookOpen} onClose={() => setBookOpen(false)} />
    </div>
  );
}
