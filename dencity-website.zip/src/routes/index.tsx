import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import {
  Header,
  Hero,
  Services,
  About,
  Pricing,
  Reviews,
  Gallery,
  Contact,
  Footer,
  BookingModal,
  FloatingCTA,
  useReveal,
} from "@/components/dencity";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Dencity Dental Clinic — Best Dentist in Sri Ganganagar, Rajasthan" },
      {
        name: "description",
        content:
          "Premium dental care in Sri Ganganagar — RCT, implants, whitening, orthodontics & more. Rated 5.0★ by 288 patients. Book your appointment today.",
      },
      { property: "og:title", content: "Dencity Dental Clinic — Sri Ganganagar" },
      { property: "og:description", content: "Painless dental treatments with transparent pricing. 15+ years, 10,000+ smiles." },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "/" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [
      { rel: "canonical", href: "/" },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      {
        rel: "stylesheet",
        href: "https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Sora:wght@500;600;700;800&display=swap",
      },
    ],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "Dentist",
          name: "Dencity Dental Clinic",
          address: {
            "@type": "PostalAddress",
            streetAddress: "Nagpal Colony, New Dhan Mandi",
            addressLocality: "Sri Ganganagar",
            addressRegion: "Rajasthan",
            postalCode: "335001",
            addressCountry: "IN",
          },
          telephone: "+919414094290",
          aggregateRating: {
            "@type": "AggregateRating",
            ratingValue: "5.0",
            reviewCount: "288",
          },
          priceRange: "₹₹",
        }),
      },
    ],
  }),
  component: Index,
});

function Index() {
  const [bookOpen, setBookOpen] = useState(false);
  const [dark, setDark] = useState(false);
  useReveal();

  useEffect(() => {
    document.documentElement.classList.toggle("dark", dark);
  }, [dark]);

  const openBook = () => setBookOpen(true);

  return (
    <div className="relative">
      <Header onBook={openBook} dark={dark} setDark={setDark} />
      <main>
        <Hero onBook={openBook} />
        <Services />
        <About />
        <Pricing />
        <Reviews />
        <Gallery />
        <Contact onBook={openBook} />
      </main>
      <Footer />
      <FloatingCTA onBook={openBook} />
      <BookingModal open={bookOpen} onClose={() => setBookOpen(false)} />
    </div>
  );
}
